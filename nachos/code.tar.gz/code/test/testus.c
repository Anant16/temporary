#include "syscall.h"
#define OUTER_BOUND 4
#define SIZE 100

int
main()
{
     syscall_wrapper_PrintString("hello world\n");
    int array[SIZE], i, k, sum;
    
    
    return 0;
}
