// progtest.cc 
//	Test routines for demonstrating that Nachos can load
//	a user program and execute it.  
//
//	Also, routines for testing the Console hardware device.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "console.h"
#include "addrspace.h"
#include "synch.h"
#include "syscall.h"


#define BUFFER_SIZE   1024

//----------------------------------------------------------------------
// ForkNewFunction
// 
//----------------------------------------------------------------------


void
ForkNewFunction (int dummy)
{
   currentThread->Startup();
   DEBUG('t', "returning from startup\n");
   machine->Run();
   DEBUG('t', "returning from machine->Rum()\n");
}


//----------------------------------------------------------------------
// LaunchUserProcess
// 	Run a user program.  Open the executable, load it into
//	memory, and jump to it.
//----------------------------------------------------------------------

void
LaunchUserProcess(char *filename)
{
    OpenFile *executable = fileSystem->Open(filename);
    ProcessAddressSpace *space;

    if (executable == NULL) {
	printf("Unable to open file %s\n", filename);
	return;
    }
    space = new ProcessAddressSpace(executable);    
    currentThread->space = space;

    delete executable;			// close file

    space->InitUserModeCPURegisters();		// set the initial register values
    space->RestoreContextOnSwitch();		// load page table register

    machine->Run();			// jump to the user progam
    ASSERT(FALSE);			// machine->Run never returns;
					// the address space exits
					// by doing the syscall "exit"
}

// Data structures needed for the console test.  Threads making
// I/O requests wait on a Semaphore to delay until the I/O completes.

static Console *console;
static Semaphore *readAvail;
static Semaphore *writeDone;

//----------------------------------------------------------------------
// ConsoleInterruptHandlers
// 	Wake up the thread that requested the I/O.
//----------------------------------------------------------------------

static void ReadAvail(int arg) { readAvail->V(); }
static void WriteDone(int arg) { writeDone->V(); }

//----------------------------------------------------------------------
// ConsoleTest
// 	Test the console by echoing characters typed at the input onto
//	the output.  Stop when the user types a 'q'.
//----------------------------------------------------------------------

void 
ConsoleTest (char *in, char *out)
{
    char ch;

    console = new Console(in, out, ReadAvail, WriteDone, 0);
    readAvail = new Semaphore("read avail", 0);
    writeDone = new Semaphore("write done", 0);
    
    for (;;) {
	readAvail->P();		// wait for character to arrive
	ch = console->GetChar();
	console->PutChar(ch);	// echo it!
	writeDone->P() ;        // wait for write to finish
	if (ch == 'q') return;  // if q, quit
    }
}

//----------------------------------------------------------------------
// LaunchBatchProcess
//  Run user programs.  Open the executables, load it into
//  memory, and jump to it.
//----------------------------------------------------------------------


void
LaunchBatchProcess(char *filename)
{
  
    //------------------
    char exec_name[1000];
	char priority_val_str[1000];
	int priority_val;
	int flag = 0;    
	FILE * fp;
    //---------------------------
    int sched_type;
    
    //OpenFile *executablelist = fileSystem->Open(filename);
    OpenFile* executable;
    //ProcessAddressSpace *space;
    printf("lbp 1\n");
    NachOSThread* childThread;
    //if (executablelist == NULL) {
    //printf("Unable to open file %s\n", filename);
    //return;
    //}
    printf("lbp1.1\n");
    fp = fopen(filename, "r");
    printf("lbp1.2\n");
    fscanf(fp, "%d", &sched_type);
    printf("lbp 2\n");
    //int filelength = executablelist->Length();
    printf("lbp 3\n");
    char filebuffer[BUFFER_SIZE];
    printf("lbp 4\n");
    //executablelist->ReadAt(filebuffer, filelength-1, 0); //filelength - 1 ??
    printf("lbp 5\n");
    char name[128], priority[10];
    int priority_int;
    int i=0, j=0; 
   

    //for main thread.
    priorityValue[currentThread->GetPID()] = 0;
    basePriorityValue[currentThread->GetPID()] = 50;
    /*
    while(filebuffer[i] != '\n')
    {
        name[j] = filebuffer[i];
        ++i, ++j;
    }
    name[j] = '\0';
    sched_type = atoi(name);
    */
    scheduler->type = sched_type;
    printf("lbp 6, sched_type=%d\n", sched_type);
    while( 1 )
    {
        if(flag == 0)
			if(fscanf(fp, "%s", exec_name) == EOF) break;
		if(flag == 1)
			sscanf(priority_val_str, "%s", exec_name);

		if(fscanf(fp, "%s", priority_val_str) == EOF) break;
		if( priority_val_str[0] > '9' || priority_val_str[0] < '0' )
		{
			priority_val = 100;
			flag = 1;
		}
		else
		{
			sscanf(priority_val_str, "%d", &priority_val);
			flag = 0;
		}
        /*
        printf("lbp in while,  i=%d\n",i);
        while(filebuffer[i] =='\n' || filebuffer[i] == ' ') ++i;

        printf("lbp 8\n");
        j=0;
        while(i<filelength && (filebuffer[i] != ' ' || filebuffer[i] != '\n' ))
        {   
           // printf("lbp in while-2 i=%d, j=%d\n",i,j);
            name[j++] = filebuffer[i++];
        }
        name[j] = '\0';

        printf("lbp 9\n");
        while(filebuffer[i]==' ') ++i;

        if(filebuffer[i] == '\n')
        {
            priority_int = 100;
        }
        else
        {
            //read priority
            printf("lbp 10\n");
            j=0;
            while(i<filelength && (filebuffer[i]!='\n' || filebuffer[i]!=' '))
            {
                priority[j++] = filebuffer[i++];
            }
            priority[j] = '\0';
            priority_int = atoi(priority);

            while(filebuffer[i]!='\n') ++i;
        }
        */
        executable = fileSystem->Open(exec_name);

        if (executable == NULL) {
        printf("Unable to open file %s\n", exec_name);
        return;
        }
        childThread = new NachOSThread(exec_name);
        childThread->space = new ProcessAddressSpace(executable);

        basePriorityValue[childThread->GetPID()] = 50;
        priorityValue[childThread->GetPID()] = priority_val + basePriorityValue[childThread->GetPID()];
        
        printf("lbp 7\n");
        delete executable;          // close file

        childThread->space->InitUserModeCPURegisters();      // set the initial register values
        childThread->SaveUserState();
        //childThread->space->RestoreContextOnSwitch();        // load page table register
        childThread->ThreadFork(ForkNewFunction, 0);
        
    }
    //delete executablelist;

    //syscall_wrapper_Exit(0);
    printf("[pid %d]: Exit called. totalTicks: %d\n", currentThread->GetPID(), stats->totalTicks);
       // We do not wait for the children to finish.
       // The children will continue to run.
       // We will worry about this when and if we implement signals.
       exitThreadArray[currentThread->GetPID()] = true;

       // Find out if all threads have called exit
       for (i=0; i<thread_index; i++) {
          if (!exitThreadArray[i]) break;
       }
       currentThread->Exit(i==thread_index, 0);
        
    
}


